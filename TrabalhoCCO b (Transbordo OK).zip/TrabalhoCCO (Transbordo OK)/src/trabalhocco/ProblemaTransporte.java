/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhocco;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toCollection;
import java.util.*;
 
public class ProblemaTransporte {
 
    private static int[] demanda;
    private static int[] oferta;
    private static double[][] custos; //matriz de custos
    private static Remessa[][] mat; //matriz para salvar dados da remessa (custo e quantidade)
 
    private static class Remessa {//Classe para salvar valores da remessa
        final double custoUnidade;
        final int r, c;
        double quant;
 
        public Remessa(double q, double cpu, int r, int c) { 
            quant = q;
            custoUnidade = cpu;
            this.r = r;
            this.c = c;
        }
    }
    
    static void balancearMat(List<Integer> forn, List<Integer> dst)
    {
        int totalForn = forn.stream().mapToInt(i -> i).sum();
        int totalDst = dst.stream().mapToInt(i -> i).sum();
        
        System.out.println("\nValor total de oferta:"+totalForn);
        System.out.println("Valor total de demanda:"+totalDst+"\n");
        
            if (totalForn > totalDst){
                System.out.println("Oferta maior que demanda, balanceamento OK!\n");
                dst.add(totalForn - totalDst);
            }else if (totalDst > totalForn){
                System.out.println("Demanda maior que oferta, balanceamento OK!\n");
                forn.add(totalDst - totalForn);
            }
            oferta = forn.stream().mapToInt(i -> i).toArray();
            demanda = dst.stream().mapToInt(i -> i).toArray();
                    
    }
 
    static void getDados(){
 
            Scanner sc = new Scanner(System.in);
            System.out.print("Digite a quantidade de forncedores: ");
            int numFornecedores = sc.nextInt();//pega quantidade de fornecedores
            System.out.print("Digite a quantidade de destinos: ");
            int numDestinations = sc.nextInt();//pega quantidade de destinos
            
            System.out.print("Digite a quantidade de nós de transbordo: ");
            int numTranshipment = sc.nextInt();//pega quantidade de transbordos
               
            List<Integer> forn = new ArrayList<>(); // cria lista para colocar valor dos fornecedores
            List<Integer> dst = new ArrayList<>(); // cria lista para colocar valor dos destinos
            double u; 
            String k;
            
            System.out.println("\nPreencher valores de oferta");
            
            for (int i = 0; i < numFornecedores+numTranshipment; i++){ //preenche a lista de fornecedores
                System.out.print("Valor "+i+":");                                 
                forn.add(sc.nextInt());
            }
            
            System.out.println("\nPreencher valores de demanda");
            for (int i = 0; i < numDestinations+numTranshipment; i++){//preenche a lista de destinos
                System.out.print("Valor "+i+":");  
                dst.add(sc.nextInt());
            }
            
            balancearMat(forn,dst);
                        
            custos = new double[oferta.length][demanda.length];// aloca matriz de custos
            mat = new Remessa[oferta.length][demanda.length];// aloca matriz de remessas
            
            System.out.println("Preencher Matriz de custos");
            System.out.println("Caso não exista caminho digite 'M'");
            for (int i = 0; i < numFornecedores+numTranshipment; i++)//preenche matriz de custos
                for (int j = 0; j < numDestinations+numTranshipment; j++){
                    System.out.print("Valor["+i+"]"+"["+j+"]:");
                
                    k = sc.next();
                                        
                    if(Character.isDigit(k.charAt(0)))//Se o caractere for um digito
                        u = Double.parseDouble(k);//converte caractere em double
                    else
                        u=Double.MAX_VALUE;
                
                    custos[i][j] = u;
                }
            
            System.out.println("\n\nMatriz de custos:");
            for (int i = 0; i < numFornecedores+numTranshipment; i++){//imprime matriz de custos
                for (int j = 0; j < numDestinations+numTranshipment; j++){
                    if(custos[i][j]!=Double.MAX_VALUE)
                        System.out.print(custos[i][j]+"  ");
                    else
                        System.out.print("M  ");
                }
                System.out.println();
            }
            System.out.println("\n");
        
    }
 
    static void cantoNoroeste() {
 
        for (int r = 0, cantonoroeste = 0; r < oferta.length; r++) //enquanto r < que o tamanho do vetor oferta
            for (int c = cantonoroeste; c < demanda.length; c++) { // enquanto c < que o tamanho do vetor de demanda
 
                int quant = Math.min(oferta[r], demanda[c]); // seleciona o menor entre a demanda e a oferta
                if (quant > 0) { 
                    mat[r][c] = new Remessa(quant, custos[r][c], r, c);// coloca os valores na posição [r][c] da matriz
 
                    oferta[r] -= quant; //diminui da oferta
                    demanda[c] -= quant;//diminui da demanda
 
                    if (oferta[r] == 0) {
                        cantonoroeste = c; 
                        break;
                    }
                }
            }
    }
 
    static void steppingStone() {
        double maxReduction = 0;
        Remessa[] move = null;
        Remessa leaving = null;
 
        corrigirCaso();
 
        for (int r = 0; r < oferta.length; r++) {
            for (int c = 0; c < demanda.length; c++) {
 
                if (mat[r][c] != null)
                    continue;
 
                Remessa trial = new Remessa(0, custos[r][c], r, c);
                Remessa[] path = getCaminhoFechado(trial);
 
                double reduction = 0;
                double lowestQuantity = Integer.MAX_VALUE;
                Remessa leavingCandidate = null;
 
                boolean plus = true;
                for (Remessa s : path) {
                    if (plus) {
                        reduction += s.custoUnidade;
                    } else {
                        reduction -= s.custoUnidade;
                        if (s.quant < lowestQuantity) {
                            leavingCandidate = s;
                            lowestQuantity = s.quant;
                        }
                    }
                    plus = !plus;
                }
                if (reduction < maxReduction) {
                    move = path;
                    leaving = leavingCandidate;
                    maxReduction = reduction;
                }
            }
        }
 
        if (move != null) {
            double q = leaving.quant;
            boolean plus = true;
            for (Remessa s : move) {
                s.quant += plus ? q : -q;
                mat[s.r][s.c] = s.quant == 0 ? null : s;
                plus = !plus;
            }
            steppingStone();
        }
    }
 
    static LinkedList<Remessa> matList() {//Converte a matriz em lista
        return stream(mat)
                .flatMap(row -> stream(row))
                .filter(s -> s != null)
                .collect(toCollection(LinkedList::new));
    }
 
    @SuppressWarnings("empty-statement")
    static Remessa[] getCaminhoFechado(Remessa s) {
        LinkedList<Remessa> path = matList();// Transforma a matriz em uma lista
        path.addFirst(s); 
 
        // remove  e continua removendo os elementos que não tem um
        // vizinho horizontal e verticalmente
        while (path.removeIf(e -> {
            Remessa[] nbrs = getVizinhos(e, path);
            return nbrs[0] == null || nbrs[1] == null;
        }));
 
        // Coloque os elementos restantes na ordem mais||menos correta
        Remessa[] stones = path.toArray(new Remessa[path.size()]);
        Remessa prev = s;
        for (int i = 0; i < stones.length; i++) {
            stones[i] = prev;
            prev = getVizinhos(prev, path)[i % 2];
        }
        return stones;
    }
 
    static Remessa[] getVizinhos(Remessa s, LinkedList<Remessa> lst) {
        Remessa[] nbrs = new Remessa[2];
        for (Remessa o : lst) {
            if (o != s) {
                if (o.r == s.r && nbrs[0] == null)
                    nbrs[0] = o;
                else if (o.c == s.c && nbrs[1] == null)
                    nbrs[1] = o;
                if (nbrs[0] != null && nbrs[1] != null)
                    break;
            }
        }
        return nbrs;
    }
 
    static void corrigirCaso() {
        final double eps = Double.MIN_VALUE;//Armazena valor muito pequeno
        
        if (oferta.length + demanda.length - 1 != matList().size()) { 
            for (int r = 0; r < oferta.length; r++)
                for (int c = 0; c < demanda.length; c++) {
                    if (mat[r][c] == null) {
                        Remessa dummy = new Remessa(eps, custos[r][c], r, c);
                        if (getCaminhoFechado(dummy).length == 0) {
                            mat[r][c] = dummy;
                            return;
                        }
                    }
                }
        }
    }
 
    static void printResultado() {
        System.out.printf("Solução Otima:\n");
        double custoTotal = 0;
 
        for (int r = 0; r < oferta.length; r++) {
            for (int c = 0; c < demanda.length; c++) {
 
                if (mat[r][c] != null && mat[r][c].r == r && mat[r][c].c == c) {
                    System.out.printf(" %3s ", (int) mat[r][c].quant);
                    custoTotal += (mat[r][c].quant * mat[r][c].custoUnidade);
                } else
                    System.out.printf("  -  ");
            }
            System.out.println();
        }
        System.out.printf("%nTotal custos: %s%n%n", custoTotal);
    }
 
    public static void main(String[] args) throws Exception {
            getDados();
            cantoNoroeste();
            steppingStone();
            printResultado();     
    }
}
    

